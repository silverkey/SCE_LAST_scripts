#!/usr/bin/perl
use strict;
use warnings;
use File::Copy;
use Cwd;
use Data::Dumper;

use lib "$ENV{'HOME'}/src/mce-0.1";
use Bio::MCE::conf::Conf_49 qw(%CONF);
use lib $CONF{'BIOPERL'};
use lib $CONF{'BIOPERL_RUN'};
use lib $CONF{'ENSEMBL'}; 
use lib $CONF{'COMPARA'}; 

use Bio::MCE::Pipeline::Utils;

my $usage = "\n\tperl $0 [db] [usr] [pwd] [host] [feature_pair_id] [fasta of the ganome with all the path] [temp dir to create and in which to work without final '/']\n\n";
die $usage if scalar(@ARGV) != 7;

my $DBH = DBI->connect("dbi:mysql:$ARGV[0]:$ARGV[3]",$ARGV[1],$ARGV[2],{PrintError => 1, RaiseError => 1});

my $HMM_FOLDER = '/home/remo/hmm_rs9_valis_6/';

my $FASTA = $ARGV[5];
my $GENOME = get_genome();
my $ID = $ARGV[4];
my $HMMB = '/usr/local/bio/bin/hmmb';
my $HMMFS = '/usr/local/bio/bin/hmmfs';

# THIS COULD BE AN INITIALIZE...
my $param_string = join(';',@ARGV);
Bio::MCE::Pipeline::Utils->insert_analysis($DBH,$ENV{'PBS_JOBID'},$0,$param_string,5);
my $status = 'launched';
my $start_dir = $ENV{'START_TMPDIR'};
my $WORKING_DIR = $ARGV[6];
mkdir($WORKING_DIR);
chdir($WORKING_DIR) or die "ERROR: No directory $WORKING_DIR!\n";

my $FILE = make_aln_file();
my $HMM = build_model();
my $SCAN = scan_genome();
parse_scan();
$status = 'finished';

sub make_aln_file {
	my $filename = "$ID\.msf";
	my $sth = $DBH->prepare('SELECT * FROM sce_aln WHERE feature_pair_id = '.$ID);
	$sth->execute;
	my $row = $sth->fetchrow_hashref;
  my $aln_string = $row->{'aln'};
  open(MEMORY,'<', \$aln_string);
  my $fh = Bio::AlignIO->new(-format => 'clustalw',
                             -fh => \*MEMORY);
  my $aln = $fh->next_aln;
	my $outIO = Bio::AlignIO->new(-file => ">$filename",
																-format => 'msf');
	$outIO->write_aln($aln);
	close(MEMORY);
	$outIO->close;
  return $filename;
}

sub build_model {
	my $hmm = "$FILE";
	$hmm =~ s/msf/hmm/;
	my $command = "$HMMB -d $hmm $FILE";
	system($command);
	return $hmm;
}

sub scan_genome {
	my $hmm_out = "$ID\_hmmer\_$GENOME\.out";
	my $command = "$HMMFS -c -F $HMM $FASTA > $hmm_out";
	system($command);
	return $hmm_out;
}

sub parse_scan {
	open(IN,$SCAN);
	open(OUT,">$SCAN\.parsed");
#	print OUT "hmm_id\thmm_start\thmm_end\thit_id\thit_start\thit_end\tscore\tHMMconsensus\tmatchline\thit\torganism\n";
	my $start_point = 0;
	while(my $row = <IN>) {
	  chomp($row);
	  $start_point = 1 if $row =~ /^Score/;
	  next unless $start_point;
	  next unless $row =~ /^\d+/;
	  my @field = split(/\s+/,$row);
	  my @last = split(/\s+/,$field[5]);
	  my $next1 = <IN>;
	  my $HMMconsensus = <IN>;
	  chomp($HMMconsensus);
	  $HMMconsensus =~ s/^ +//g;
	  $HMMconsensus =~ s/ +$//g;
	  my $matchline = <IN>;
	  chomp($matchline);
	  $matchline =~ s/^ +//g;
	  $matchline =~ s/ +$//g;
	  my $hit = <IN>;
	  chomp($hit);
	  $hit =~ s/ +(.+) +(.+) +([ATCGN\-]+) +(.+)/$3/;
	  $hit =~ s/^ +//g;
	  $hit =~ s/ +$//g;
	  my $empty = <IN>;
		if($field[0] >= 15) {
		  print OUT "$ID\t$field[3]\t$field[4]\t$last[0]\t$field[1]\t$field[2]\t$field[0]\t$HMMconsensus\t$matchline\t$hit\t$GENOME\n"; # FILTRO SULLO SCORE
		}
	}
	close(OUT);
	$DBH->do("LOAD DATA LOCAL INFILE \'$SCAN\.parsed\' INTO TABLE hmm");
	system("tar -czvf $SCAN\.tar\.gz $SCAN");
	system("cp $SCAN\.tar\.gz $HMM_FOLDER");
}

sub get_genome {
	$FASTA =~ /(\w)\w+\_(\w).+/;
	return uc($1.$2);
}

END {
  my $error_string = "$!" || 'NULL';
  Bio::MCE::Pipeline::Utils->manage_error($ARGV[0],$ARGV[1],$ARGV[2],$ARGV[3],$ENV{'PBS_JOBID'},$error_string,$status);
  chdir("$start_dir");
  system("rm -fr $WORKING_DIR");
}
